import boto3
import json
def lambda_handler(event, context):
    session = boto3.Session(region_name='eu-west-1')
    ec2 = boto3.resource('ec2')
    subnets = ec2.subnets.all()
    for subnet in list(subnets):
        free_ips = subnet.available_ip_address_count
        n = int(subnet.cidr_block.split('/')[1])
        cidr_ips = 2**(32-n)
        used_ips = cidr_ips - free_ips
     #    print('subnet={:s} , free={:d}'.\
      #      format(subnet.id, free_ips))
        data = {'subnet' : subnet.id , 'free': free_ips}
        json_str = json.dumps(data)
        print(json_str)